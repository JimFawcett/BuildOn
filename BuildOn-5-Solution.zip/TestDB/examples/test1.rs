fn main() {
    print!("\n  -- test1 --");
    print!("\n\n  That's all Folks!\n\n");
}
fn main() {
    print!("\n  -- test2 --");
    print!("\n\n  That's all Folks!\n\n");
}